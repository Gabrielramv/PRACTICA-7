#include<stdio.h>
#include<stdlib.h>

typedef struct Fecha{ 
	int anio,mes,dia;
}Fecha;
typedef struct Disco{
	int NC;
	float Precio;
	Fecha fechadecreacion;
	char Titulo[40];
	char Artista[30];
}Disco;
	

Disco solicitarDatos(){
	Disco Disco;
	printf("Fecha de compra\n");
    printf("Ingrese el a%co: ",164);
	scanf("%d",&Disco.fechadecreacion.anio);	
	printf("Ingrese el mes: ");
		fflush(stdin);
	scanf("%d",&Disco.fechadecreacion.mes);
	printf("Ingrese el d%ca: ",161);
		fflush(stdin);
	scanf("%d",&Disco.fechadecreacion.dia);		
	printf("Ingrese el t%ctulo: ",161);
	fflush(stdin);
	gets(Disco.Titulo);
	printf("Ingrese el artista: ");
	gets(Disco.Artista);
	printf("Ingresa el n%cmero de canciones: ",163);
	scanf("%d",&Disco.NC);
	printf("Ingrese el precio: ");
	fflush(stdin);
	scanf("%f",&Disco.Precio);
	
	return Disco;
}
	
float calcularSuma(Disco Disco[], int dis ){
	int i;
	
	float suma=0;

	for (i=0;i<dis;i++){
	suma=(float)Disco[i].Precio+suma;
	}
	return suma;
}
void imprimirDisco(Disco disco){

	
	printf("Fecha de compra: %d-%d-%d \n",disco.fechadecreacion.anio,disco.fechadecreacion.mes,disco.fechadecreacion.dia);
	printf("T%ctulo: %s \n",161,disco.Titulo);
	printf("Artista:  %s\n",disco.Artista);
	printf("N%cmero de canciones: %d \n",163,disco.NC);
	printf("Precio: $ %g \n",disco.Precio);

	
}
Disco descuento(Disco Disco){
	
	Disco.Precio=25*Disco.Precio/100;
	printf("Precio con descuento : $ %g \n",Disco.Precio);
	return Disco;
	
}

float calcularSuma( Disco Disco[], int);
Disco descuento(Disco);
void imprimirDisco(Disco disco);
Disco solicitarDatos();

int main(){
	int i,dis,opc;
	printf("Este programa almacena datos de una coleccion de CD de musica\n");
	printf(" %cCuantos discos deseas ingresar?",168);
	scanf("%d",&dis);
	Disco Disco[dis]; 
	system ("cls");
	eti_1:
	printf("Indique la opcion que desea realizar:\n");
	printf("1)Ingresar datos\n");
	printf("2)Mostrar datos\n");
	printf("3)Aplicar descuento\n");
	printf("4)Obtener ganancia\n");
	printf("5)Para salir\n");
	scanf("%d",&opc);
	switch (opc){
		case 1:
	for (i=0;i<dis;i++){
	printf("Disco %d \n",i+1);
	printf("===================== \n");
	Disco[i]=solicitarDatos();
	//solicitarDatos();
	printf("**********DATOS GUARDADOS***********\n");
	}
	system ("cls");
	goto eti_1;
	break;	
	case 2:
	for (i=0;i<dis;i++){
	printf("Disco %d \n",i+1);
	imprimirDisco(Disco[i]);
	printf("\n");
	}
	system ("pause");
	system ("cls");
    goto eti_1;
	break;
	case 3:
	for (i=0;i<dis;i++){
	descuento(Disco[i]);
	}
	system ("pause");
	system ("cls");
    goto eti_1;
	break;
	case 4:
	printf("Ganancia: %g\n",calcularSuma(Disco,dis ));
	system ("pause");
	system ("cls");
	goto eti_1;
	break;
	case 5:
	break;
	default:
		printf("Opcion erronea");
	break;
}
}


