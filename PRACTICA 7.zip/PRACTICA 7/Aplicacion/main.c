#include <stdio.h>

#include <stdlib.h>



void clisol(int cf);

void tiempo(int cf);

void clillu(int cv);



 struct focos

 {

 int estado; //Encendido o apagado

 int inten;  //Nivel de intensidad (1 a 3)

 }foco[30];

 

 struct puertas

 {

 int estado; //Abierta o cerrada

 int ext;    //Si conecta o no al exterior de la propiedad

 }puerta[30];



 struct ventanas

 {

 int estado; //Abierta o cerrada

 int ext;    //Si conecta o no al exterior de la propiedad

 int nivel;  //Piso de la casa en el que se encuentra

 }ventana[30];

 

void portada()

{

printf("Instituto Politecnico Nacional");

printf("\nUnidad Profesional Interdisciplinaria en Ingenieria y Tecnologias Avanzadas.");

printf("\n\nPractica 7: Problema de Aplicacion:");

printf("\nRobot in-house.\n");

system("pause");

system("cls");

}



int inicializacion()

{

int cf,cp,cv,i,*c,p,j=0;

char x;

printf("Para inicializar, es necesiario obtener algunos datos de la casa.\n");

system("pause");

system("cls");

do

{

printf("Ingrese el numero de focos de la casa: ");

scanf("%d",&cf);

 if(cf==0)

 printf("Por su seguridad, la casa necesita iluminacion. Por favor, sea realista y vuelva a ingresar correctamente.\n");

 else

 j=1;

}while(j==0);

for(i=0;i<cf;i++)

{

foco[i].inten=3;

foco[i].estado=1;

}

system("pause");

system("cls");

do

{

j=0;

printf("Ingrese el numero de puertas de la casa: ");

scanf("%d",&cp);

 if(cp==0)

 printf("Es imposible que la casa no tenga puertas. Por favor, sea realista y vuelva a ingresar correctamente.\n");

 else

 {

  if(cp==1)

  {

  printf("Por obvias razones de construccion, esa puerta sera tomada como exterior.\n");

  puerta[0].ext=1;

  j=1;

  }

  else

  {

  printf("Por obvias razones de construccion, la primera puerta sera tomada como exterior.\n");

  puerta[0].ext=1;

   for(i=1;i<cp;i++)

   {

    do

    {

    j=0;

    fflush(stdin);

    printf("La puerta %d es interior o exterior?\na.- Interior\nb.- Exterior\n",i+1);

    scanf("%c",&x);

     if(x!='a' && x!='A' && x!='b' && x!='B')

     printf("Caracter invalido. Vuelva a ingresar correctamente.\n");

     else

     {

     j=1;

      if(x=='a'||x=='A')

      puerta[i].ext=0;	

      else

      puerta[i].ext=1;

     }

    }while(j==0);

   }

  }

 }

}while(j==0);

for(i=0;i<cp;i++)

{

puerta[i].estado=1;

}

system("pause");

system("cls");

do

{

j=0;

printf("Ingrese el numero de ventanas de la casa: ");

scanf("%d",&cv);

 if(cv==0)

 printf("Por razones vitales de oxigeno, la casa necesita ventanas. Por favor, sea realista y vuelva a ingresar correctamente.\n");

 else

 {

  for(i=0;i<cv;i++)

  {

   do

   {	

   j=0;	

   fflush(stdin);

   printf("La ventana %d es interior o exterior?\na.- Interior\nb.- Exterior\n",i+1);

   scanf("%c",&x);

    if(x!='a' && x!='A' && x!='b' && x!='B')

    printf("Caracter invalido. Vuelva a ingresar correctamente.\n");

    else

    {

    j=1;

     if(x=='a'||x=='A')

     ventana[i].ext=0;

     else

     ventana[i].ext=1;

    } 

   }while(j==0);

   do

   {

   j=0;

   fflush(stdin);

   printf("En que piso se encuentra?\n0.- Planta baja\n1.- Primer piso\n2.- Segundo piso\n");

   scanf("%d",&p);

    if(p!=0 && p!=1 && p!=2)

    printf("Caracter invalido. Vuelva a ingresar correctamente.\n");

    else

    {

    j=1;

    ventana[i].nivel=p;

    }		

   }while(j==0);

  }

 } 

}while(j==0);

for(i=0;i<cv;i++)

{

ventana[i].estado=1;

}

system("pause");

system("cls");

printf("Recuento de los datos:\n");

 if(cf==1)

 printf("- 1 foco.\n");

 else

 printf("- %d focos.\n",cf);

 if(cp==1)

 printf("- 1 puerta al exterior.\n");

 else

 {

 printf("- %d puertas, de las cuales:\n",cp);

 printf(" - Puerta No. 1: Al exterior.\n");

  for(i=1;i<cp;i++)

  {

  printf(" - Puerta No. %d: ",i+1);

   if(puerta[i].ext==0)

   printf("Al interior.\n");

   else

   printf("Al exterior.\n");	

  }		

 }

 if(cv==1)

 {

 printf("- 1 ventana ");

  if(ventana[i].ext==0)

  printf(" al interior, ");

  else

  printf(" al exterior, ");

  if(ventana[i].nivel==0)

  printf("en planta baja.\n");

  else

  {

   if(ventana[i].nivel==1) 

   printf("en el primer piso.\n");

   else

   printf("en el segundo piso.\n");		

  }	

 }

 else

 {

 printf("- %d ventanas, de las cuales:\n",cv);

  for(i=0;i<cv;i++)

  {

  printf(" - Ventana No. %d: ",i+1);

   if(ventana[i].ext==0)

   printf("Al interior, ");

   else

   printf("Al exterior, ");

   if(ventana[i].nivel==0)

   printf("en planta baja.\n");

   else

   {

    if(ventana[i].nivel==1)

	printf("en el primer piso.\n");

	else

	printf("en el segundo piso.\n");		

   }	

  }	

 }

printf("\nGenerando simulacion de acuerdo a los datos ingresados...\n");

system("pause");

system("cls");

c=(int*)malloc(3*sizeof(int));

c[0]=cf;

c[1]=cp;

c[2]=cv;

return c;

}



void impresion(int cf,int cp,int cv)

{

int i;

char sep[]="~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.";

printf("%s\n\t\t      Estado de la casa\n%s\n",sep,sep);

printf("Iluminacion:\n");

 for(i=0;i<cf;i++)

 {

 printf("Foco No. %d: ",i+1);

  if(foco[i].estado==1)

  {

  printf("Encendido a ");

   if(foco[i].inten==1)

   printf("intensidad minima.\n");

   else

   {

    if(foco[i].inten==2)

	printf("intensidad natural.\n");

	else

	printf("intensidad maxima.\n");		

   }	

  }

  else

  printf("Apagado.\n");	

 }

printf("%s\nPuertas:\n",sep);

 for(i=0;i<cp;i++)

 {

 printf("Puerta No. %d: ",i+1);

  if(puerta[i].ext==1)

  printf("Al exterior ");

  else

  printf("Al interior ");

  if(puerta[i].estado==1)

  printf("abierta.\n");

  else

  printf("cerrada.\n");		

 }

printf("%s\nVentanas:\n",sep);

 for(i=0;i<cv;i++)

 {

 printf("Ventana No. %d: ",i+1);

  if(ventana[i].ext==1)

  printf("Al exterior ");

  else

  printf("Al interior ");

  if(ventana[i].estado==1)

  printf("abierta en ");

  else

  printf("cerrada en ");

  if(ventana[i].nivel==0)

  printf("planta baja.\n");

  else

  {

   if(ventana[i].nivel==1)

   printf("el primer piso.\n");

   else

   printf("el segundo piso.\n");		

  }		

 }

}



int seleccion(int s,int cf,int cv,int cp)

{

int selec,c=0;

char sal,cli;

char sep[]="~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.";

printf("%s\n\t\t     Que desea hacer?\n%s\n",sep,sep);

 if(s==0)

 printf("1.- Salir de casa\n");

 else

 printf("1.- Regresar a casa\n");

printf("2.- Cambiar hora\n3.- Actualizar clima\n0.- Salir\n");

do

{

scanf("%d",&selec);

 if(selec!=0 && selec!=1 && selec!=2 && selec!=3)

 printf("Caracter invalido. Vuelva a ingresar correctamente.\n");

 else

 c=1;

}while(c==0);

switch(selec)

{

 case 1:

  if(s==0)

  {

  c=0;

  printf("Por cuanto tiempo desea salir?:\n");

  printf("a.- Periodo breve (Puertas a exterior cerradas, ventanas a exterior en planta baja cerradas, focos en intensidad minima.\n");

  printf("b.- Periodo largo (Todo cerrado y focos apagados).\n");

  do

  {

  scanf("%c",&sal);

   if(sal!='a' && sal!='A' && sal!='b' && sal!='B')

   printf("Caracter invalido. Vuelva a ingresar correctamente.\n");

   else

   c=1; 

  }while(c==0);

   if(sal=='a' || sal=='A')

   s=salbreve(cf,cp,cv);

   else

   s=sallargo(cf,cp,cv);

  }

  else

  {

  s=regreso(cf,cp,cv);

  }

 break;

 case 2:

  tiempo(cf);

 break;

 case 3:

  c=0;

  printf("Como esta el clima?\na.- Soleado\nb.- Lluvioso\n");

  do

  {

  scanf("%c",&cli);

   if(cli!='a' && cli!='A' && cli!='b' && cli!='B')

   printf("Caracter invalido. Vuelva a ingresar correctamente.\n");

   else

   c=1; 

  }while(c==0);

   if(cli=='a' || cli=='A')

   clisol(cf);

   else

   clillu(cv);

 break;

 case 0:

  return 0;

 break;

 default:

  printf("Caracter invalido. Vuelva a ingresar correctamente.\n");		

}

return selec;

}



int salbreve(int cf,int cp,int cv)

{

int s=1,i;

 for(i=0;i<cf;i++)

 {

 foco[i].inten=1;		

 }

 for(i=0;i<cp;i++)

 {

  if(puerta[i].ext==1)

  puerta[i].estado=0;		

 }

 for(i=0;i<cv;i++)

 {

  if(ventana[i].ext==1)

  {

   if(ventana[i].nivel==0)

   ventana[i].estado=0;		

  }		

 }

return s;	

}



int sallargo(int cf,int cp,int cv)

{

int s=1,i;

 for(i=0;i<cf;i++)

 {

 foco[i].estado=0;		

 }

 for(i=0;i<cp;i++)

 {

 puerta[i].estado=0;		

 }

 for(i=0;i<cv;i++)

 {

 ventana[i].estado=0;		

 }		

return s;	

}



int regreso(int cf,int cv,int cp)

{

int s=0,i;

 for(i=0;i<cf;i++)

 {

 foco[i].estado=0;		

 }

 for(i=0;i<cp;i++)

 {

 puerta[i].estado=0;		

 }

 for(i=0;i<cv;i++)

 {

 ventana[i].estado=0;		

 }

return s;

}



void tiempo(int cf)

{

int i,h,c=0;

printf("Introduzca el tiempo en formato de 24Hrs:\n");

do

{

scanf("%d",&h);

 if(h<0 || h>24)

 printf("Hora invalida. Vuelva a ingresar correctamente.\n");

 else

 c=1;

}while(c==0);

 if(h>=8 && h<=20)

 {

  for(i=0;i<cf;i++)

  {

  foco[i].estado=0;		

  }

 }

 else

 {

  for(i=0;i<cf;i++)

  {

  foco[i].inten=2;		

  }		

 }

}



void clisol(int cf)

{

int i;

 for(i=0;i<cf;i++)

 {

 foco[i].estado=0;	

 }

}



void clillu(int cv)

{

int i;

 for(i=0;i<cv;i++)

 {

 ventana[i].estado=0;		

 }

}



int main(int argc, char *argv[]) 

{

int *ptc,x,s=0;

portada();

printf("Bienvenido al sistema de monitoreo de iluminacion y accesos de una casa.\n");

ptc=inicializacion();

int cf=*(ptc);

int cp=*(ptc+1);

int cv=*(ptc+2);

do

{

impresion(cf,cp,cv);

printf("\n");

x=seleccion(s,cf,cp,cv);

system("pause");

system("cls");

}while(x!=0);

printf("Muchas gracias por su colaboracion.\n");

system("pause");

return 0;

}


